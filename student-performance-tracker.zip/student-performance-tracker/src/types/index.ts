export type ExamType = "Midterm" | "Final" | "Quarterly";

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarUrl?: string;
}

export interface Student {
  id: string;
  name: string;
  admissionNumber: string;
  class: string;
  createdAt: string;
}

export type StudentInput = Omit<Student, "id" | "createdAt">;

export interface Mark {
  id: string;
  studentId: string;
  examType: ExamType;
  marks: number;
}

export type MarkInput = Omit<Mark, "id">;

/** A student joined with its marks, used by detail/analytics views. */
export interface StudentWithMarks extends Student {
  marks: Record<ExamType, number | null>;
  average: number | null;
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

export interface PaginationParams {
  page: number;
  pageSize: number;
  search?: string;
}

export interface DashboardStats {
  totalStudents: number;
  midtermEntries: number;
  finalEntries: number;
  quarterlyEntries: number;
}

export interface AnalyticsSummary {
  highestScore: number | null;
  lowestScore: number | null;
  averageScore: number | null;
  topStudent: { id: string; name: string; average: number } | null;
}

export interface ExamAverages {
  examType: ExamType;
  average: number;
}

export interface Credentials {
  email: string;
  password: string;
  remember?: boolean;
}

export interface AuthSession {
  token: string;
  user: User;
}

/** Generic select option used by FormSelect and filters. */
export interface SelectOption<T extends string = string> {
  label: string;
  value: T;
}
