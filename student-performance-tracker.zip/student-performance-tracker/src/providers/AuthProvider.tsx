import { useCallback, useEffect, useMemo, useState } from "react";
import { authService } from "@/services/auth.service";
import type { Credentials, User } from "@/types";
import { AuthContext, type AuthContextValue } from "./auth-context";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    const session = authService.getStoredSession();
    if (session) setUser(session.user);
    setIsInitializing(false);
  }, []);

  const login = useCallback(async (credentials: Credentials) => {
    const session = await authService.login(credentials);
    setUser(session.user);
    return session;
  }, []);

  const logout = useCallback(async () => {
    await authService.logout();
    setUser(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: Boolean(user),
      isInitializing,
      login,
      logout,
    }),
    [user, isInitializing, login, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
