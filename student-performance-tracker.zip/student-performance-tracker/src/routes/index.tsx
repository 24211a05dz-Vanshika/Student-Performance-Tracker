import { createBrowserRouter, Navigate } from "react-router-dom";
import { AuthLayout } from "@/layouts/AuthLayout";
import { DashboardLayout } from "@/layouts/DashboardLayout";
import { ProtectedRoute } from "@/routes/ProtectedRoute";
import { PublicRoute } from "@/routes/PublicRoute";
import { LoginPage } from "@/pages/LoginPage";
import { DashboardPage } from "@/pages/DashboardPage";
import { StudentsPage } from "@/pages/StudentsPage";
import { CreateStudentPage } from "@/pages/CreateStudentPage";
import { EditStudentPage } from "@/pages/EditStudentPage";
import { StudentDetailsPage } from "@/pages/StudentDetailsPage";
import { AnalyticsPage } from "@/pages/AnalyticsPage";
import { NotFoundPage } from "@/pages/NotFoundPage";

export const router = createBrowserRouter([
  {
    element: <PublicRoute />,
    children: [
      {
        element: <AuthLayout />,
        children: [{ path: "/login", element: <LoginPage /> }],
      },
    ],
  },
  {
    element: <ProtectedRoute />,
    children: [
      {
        element: <DashboardLayout />,
        children: [
          { index: true, element: <Navigate to="/dashboard" replace /> },
          { path: "/dashboard", element: <DashboardPage /> },
          { path: "/students", element: <StudentsPage /> },
          { path: "/students/new", element: <CreateStudentPage /> },
          { path: "/students/:id", element: <StudentDetailsPage /> },
          { path: "/students/:id/edit", element: <EditStudentPage /> },
          { path: "/analytics", element: <AnalyticsPage /> },
        ],
      },
    ],
  },
  { path: "*", element: <NotFoundPage /> },
], {
  future: {
    v7_relativeSplatPath: true,
    v7_startTransition: true,
  },
});
