import { STORAGE_KEYS } from "@/constants";
import type { Mark, Student } from "@/types";

/**
 * A tiny localStorage-backed persistence layer that simulates a remote API.
 * In a real product these reads/writes would be network requests; isolating
 * them here keeps the service layer swappable.
 */

const SEED_STUDENTS: Student[] = [
  { id: "stu_01", name: "Aanya Sharma", admissionNumber: "ADM-1001", class: "Grade 10", createdAt: "2025-08-14T09:00:00.000Z" },
  { id: "stu_02", name: "Bilal Khan", admissionNumber: "ADM-1002", class: "Grade 10", createdAt: "2025-08-15T09:00:00.000Z" },
  { id: "stu_03", name: "Chen Wei", admissionNumber: "ADM-1003", class: "Grade 11", createdAt: "2025-08-16T09:00:00.000Z" },
  { id: "stu_04", name: "Diya Patel", admissionNumber: "ADM-1004", class: "Grade 9", createdAt: "2025-08-17T09:00:00.000Z" },
  { id: "stu_05", name: "Elena Rossi", admissionNumber: "ADM-1005", class: "Grade 12", createdAt: "2025-08-18T09:00:00.000Z" },
  { id: "stu_06", name: "Farhan Ali", admissionNumber: "ADM-1006", class: "Grade 11", createdAt: "2025-08-19T09:00:00.000Z" },
  { id: "stu_07", name: "Grace Okafor", admissionNumber: "ADM-1007", class: "Grade 10", createdAt: "2025-08-20T09:00:00.000Z" },
  { id: "stu_08", name: "Hiroshi Tanaka", admissionNumber: "ADM-1008", class: "Grade 12", createdAt: "2025-08-21T09:00:00.000Z" },
  { id: "stu_09", name: "Isabella Cruz", admissionNumber: "ADM-1009", class: "Grade 9", createdAt: "2025-08-22T09:00:00.000Z" },
  { id: "stu_10", name: "Jamal Brooks", admissionNumber: "ADM-1010", class: "Grade 11", createdAt: "2025-08-23T09:00:00.000Z" },
  { id: "stu_11", name: "Keiko Yamamoto", admissionNumber: "ADM-1011", class: "Grade 10", createdAt: "2025-08-24T09:00:00.000Z" },
  { id: "stu_12", name: "Liam O'Connor", admissionNumber: "ADM-1012", class: "Grade 12", createdAt: "2025-08-25T09:00:00.000Z" },
];

const SEED_MARKS: Mark[] = [
  { id: "mark_01", studentId: "stu_01", examType: "Midterm", marks: 82 },
  { id: "mark_02", studentId: "stu_01", examType: "Final", marks: 91 },
  { id: "mark_03", studentId: "stu_01", examType: "Quarterly", marks: 88 },
  { id: "mark_04", studentId: "stu_02", examType: "Midterm", marks: 67 },
  { id: "mark_05", studentId: "stu_02", examType: "Final", marks: 74 },
  { id: "mark_06", studentId: "stu_02", examType: "Quarterly", marks: 71 },
  { id: "mark_07", studentId: "stu_03", examType: "Midterm", marks: 95 },
  { id: "mark_08", studentId: "stu_03", examType: "Final", marks: 98 },
  { id: "mark_09", studentId: "stu_03", examType: "Quarterly", marks: 93 },
  { id: "mark_10", studentId: "stu_04", examType: "Midterm", marks: 45 },
  { id: "mark_11", studentId: "stu_04", examType: "Final", marks: 52 },
  { id: "mark_12", studentId: "stu_05", examType: "Midterm", marks: 78 },
  { id: "mark_13", studentId: "stu_05", examType: "Final", marks: 85 },
  { id: "mark_14", studentId: "stu_05", examType: "Quarterly", marks: 80 },
  { id: "mark_15", studentId: "stu_06", examType: "Midterm", marks: 61 },
  { id: "mark_16", studentId: "stu_06", examType: "Quarterly", marks: 69 },
  { id: "mark_17", studentId: "stu_07", examType: "Midterm", marks: 88 },
  { id: "mark_18", studentId: "stu_07", examType: "Final", marks: 84 },
  { id: "mark_19", studentId: "stu_07", examType: "Quarterly", marks: 90 },
  { id: "mark_20", studentId: "stu_08", examType: "Midterm", marks: 73 },
  { id: "mark_21", studentId: "stu_08", examType: "Final", marks: 79 },
  { id: "mark_22", studentId: "stu_09", examType: "Midterm", marks: 58 },
  { id: "mark_23", studentId: "stu_09", examType: "Final", marks: 64 },
  { id: "mark_24", studentId: "stu_09", examType: "Quarterly", marks: 60 },
  { id: "mark_25", studentId: "stu_10", examType: "Midterm", marks: 90 },
  { id: "mark_26", studentId: "stu_10", examType: "Final", marks: 87 },
  { id: "mark_27", studentId: "stu_11", examType: "Midterm", marks: 76 },
  { id: "mark_28", studentId: "stu_11", examType: "Final", marks: 81 },
  { id: "mark_29", studentId: "stu_11", examType: "Quarterly", marks: 78 },
  { id: "mark_30", studentId: "stu_12", examType: "Midterm", marks: 84 },
  { id: "mark_31", studentId: "stu_12", examType: "Final", marks: 89 },
  { id: "mark_32", studentId: "stu_12", examType: "Quarterly", marks: 86 },
];

function read<T>(key: string, seed: T[]): T[] {
  if (typeof window === "undefined") return [...seed];
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) {
      window.localStorage.setItem(key, JSON.stringify(seed));
      return [...seed];
    }
    return JSON.parse(raw) as T[];
  } catch {
    return [...seed];
  }
}

function write<T>(key: string, value: T[]): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export const db = {
  getStudents: () => read<Student>(STORAGE_KEYS.students, SEED_STUDENTS),
  setStudents: (students: Student[]) => write(STORAGE_KEYS.students, students),
  getMarks: () => read<Mark>(STORAGE_KEYS.marks, SEED_MARKS),
  setMarks: (marks: Mark[]) => write(STORAGE_KEYS.marks, marks),
  reset: () => {
    write(STORAGE_KEYS.students, SEED_STUDENTS);
    write(STORAGE_KEYS.marks, SEED_MARKS);
  },
};

/** Simulated network latency so loading/skeleton states are demonstrable. */
export function delay<T>(value: T, ms = 450): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

export function createId(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}
