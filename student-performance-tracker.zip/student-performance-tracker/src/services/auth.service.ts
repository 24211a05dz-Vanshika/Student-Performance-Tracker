import { DEMO_CREDENTIALS, STORAGE_KEYS } from "@/constants";
import type { AuthSession, Credentials, User } from "@/types";
import { delay } from "./db";

const DEMO_USER: User = {
  id: "usr_admin",
  name: "Alex Morgan",
  email: DEMO_CREDENTIALS.email,
  role: "Administrator",
};

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}

export const authService = {
  async login(credentials: Credentials): Promise<AuthSession> {
    await delay(null, 700);
    const emailMatches =
      credentials.email.trim().toLowerCase() === DEMO_CREDENTIALS.email;
    const passwordMatches = credentials.password === DEMO_CREDENTIALS.password;

    if (!emailMatches || !passwordMatches) {
      throw new AuthError("Invalid email or password. Please try again.");
    }

    const session: AuthSession = {
      token: `tok_${Math.random().toString(36).slice(2)}`,
      user: DEMO_USER,
    };

    const storage = credentials.remember
      ? window.localStorage
      : window.sessionStorage;
    storage.setItem(STORAGE_KEYS.session, JSON.stringify(session));
    return session;
  },

  async logout(): Promise<void> {
    await delay(null, 300);
    window.localStorage.removeItem(STORAGE_KEYS.session);
    window.sessionStorage.removeItem(STORAGE_KEYS.session);
  },

  getStoredSession(): AuthSession | null {
    const raw =
      window.localStorage.getItem(STORAGE_KEYS.session) ??
      window.sessionStorage.getItem(STORAGE_KEYS.session);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as AuthSession;
    } catch {
      return null;
    }
  },
};
