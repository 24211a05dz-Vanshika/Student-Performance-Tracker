import type {
  PaginatedResult,
  PaginationParams,
  Student,
  StudentInput,
} from "@/types";
import { createId, db, delay } from "./db";

export class NotFoundError extends Error {
  constructor(message = "Resource not found") {
    super(message);
    this.name = "NotFoundError";
  }
}

export const studentsService = {
  async list(params: PaginationParams): Promise<PaginatedResult<Student>> {
    const { page, pageSize, search = "" } = params;
    const all = db.getStudents().sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    );
    const term = search.trim().toLowerCase();
    const filtered = term
      ? all.filter(
          (s) =>
            s.name.toLowerCase().includes(term) ||
            s.admissionNumber.toLowerCase().includes(term) ||
            s.class.toLowerCase().includes(term),
        )
      : all;

    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const safePage = Math.min(page, totalPages);
    const start = (safePage - 1) * pageSize;
    const data = filtered.slice(start, start + pageSize);

    return delay({ data, total, page: safePage, pageSize, totalPages });
  },

  async getById(id: string): Promise<Student> {
    const student = db.getStudents().find((s) => s.id === id);
    if (!student) throw new NotFoundError("Student not found");
    return delay(student);
  },

  async create(input: StudentInput): Promise<Student> {
    const students = db.getStudents();
    const exists = students.some(
      (s) =>
        s.admissionNumber.toLowerCase() === input.admissionNumber.toLowerCase(),
    );
    if (exists) {
      throw new Error("A student with this admission number already exists.");
    }
    const student: Student = {
      ...input,
      id: createId("stu"),
      createdAt: new Date().toISOString(),
    };
    db.setStudents([student, ...students]);
    return delay(student);
  },

  async update(id: string, input: StudentInput): Promise<Student> {
    const students = db.getStudents();
    const index = students.findIndex((s) => s.id === id);
    if (index === -1) throw new NotFoundError("Student not found");

    const duplicate = students.some(
      (s) =>
        s.id !== id &&
        s.admissionNumber.toLowerCase() === input.admissionNumber.toLowerCase(),
    );
    if (duplicate) {
      throw new Error("A student with this admission number already exists.");
    }

    const updated: Student = { ...students[index], ...input };
    students[index] = updated;
    db.setStudents(students);
    return delay(updated);
  },

  async remove(id: string): Promise<{ id: string }> {
    const students = db.getStudents().filter((s) => s.id !== id);
    db.setStudents(students);
    // Cascade delete marks for the removed student.
    db.setMarks(db.getMarks().filter((m) => m.studentId !== id));
    return delay({ id });
  },
};
