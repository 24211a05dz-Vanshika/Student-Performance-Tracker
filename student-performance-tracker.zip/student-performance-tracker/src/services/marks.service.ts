import { EXAM_TYPES } from "@/constants";
import type { ExamType, Mark, MarkInput } from "@/types";
import { createId, db, delay } from "./db";

export const marksService = {
  async listByStudent(studentId: string): Promise<Mark[]> {
    const marks = db.getMarks().filter((m) => m.studentId === studentId);
    return delay(marks);
  },

  async marksMap(studentId: string): Promise<Record<ExamType, number | null>> {
    const marks = db.getMarks().filter((m) => m.studentId === studentId);
    const map = Object.fromEntries(
      EXAM_TYPES.map((exam) => [
        exam,
        marks.find((m) => m.examType === exam)?.marks ?? null,
      ]),
    ) as Record<ExamType, number | null>;
    return delay(map);
  },

  /** Upsert a mark for a student/exam pair (one record per pair). */
  async upsert(input: MarkInput): Promise<Mark> {
    const marks = db.getMarks();
    const index = marks.findIndex(
      (m) => m.studentId === input.studentId && m.examType === input.examType,
    );
    let record: Mark;
    if (index >= 0) {
      record = { ...marks[index], marks: input.marks };
      marks[index] = record;
    } else {
      record = { ...input, id: createId("mark") };
      marks.push(record);
    }
    db.setMarks(marks);
    return delay(record);
  },

  async remove(id: string): Promise<{ id: string }> {
    db.setMarks(db.getMarks().filter((m) => m.id !== id));
    return delay({ id });
  },
};
