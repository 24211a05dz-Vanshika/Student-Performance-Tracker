import { EXAM_TYPES } from "@/constants";
import type {
  AnalyticsSummary,
  DashboardStats,
  ExamAverages,
  ExamType,
  Student,
  StudentWithMarks,
} from "@/types";
import { db, delay } from "./db";

function buildStudentsWithMarks(): StudentWithMarks[] {
  const students = db.getStudents();
  const marks = db.getMarks();

  return students.map((student) => {
    const studentMarks = marks.filter((m) => m.studentId === student.id);
    const map = Object.fromEntries(
      EXAM_TYPES.map((exam) => [
        exam,
        studentMarks.find((m) => m.examType === exam)?.marks ?? null,
      ]),
    ) as Record<ExamType, number | null>;

    const recorded = studentMarks.map((m) => m.marks);
    const average =
      recorded.length > 0
        ? Math.round(recorded.reduce((a, b) => a + b, 0) / recorded.length)
        : null;

    return { ...student, marks: map, average };
  });
}

export const analyticsService = {
  async dashboardStats(): Promise<DashboardStats> {
    const marks = db.getMarks();
    const byType = (type: ExamType) =>
      marks.filter((m) => m.examType === type).length;

    return delay({
      totalStudents: db.getStudents().length,
      midtermEntries: byType("Midterm"),
      finalEntries: byType("Final"),
      quarterlyEntries: byType("Quarterly"),
    });
  },

  async recentStudents(limit = 5): Promise<Student[]> {
    const students = db
      .getStudents()
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      )
      .slice(0, limit);
    return delay(students);
  },

  async summary(): Promise<AnalyticsSummary> {
    const marks = db.getMarks();
    if (marks.length === 0) {
      return delay({
        highestScore: null,
        lowestScore: null,
        averageScore: null,
        topStudent: null,
      });
    }

    const scores = marks.map((m) => m.marks);
    const withMarks = buildStudentsWithMarks().filter(
      (s) => s.average !== null,
    );
    const top = withMarks.reduce<StudentWithMarks | null>((best, current) => {
      if (!best || (current.average ?? 0) > (best.average ?? 0)) return current;
      return best;
    }, null);

    return delay({
      highestScore: Math.max(...scores),
      lowestScore: Math.min(...scores),
      averageScore: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
      topStudent:
        top && top.average !== null
          ? { id: top.id, name: top.name, average: top.average }
          : null,
    });
  },

  async examAverages(): Promise<ExamAverages[]> {
    const marks = db.getMarks();
    const result = EXAM_TYPES.map((examType) => {
      const subset = marks.filter((m) => m.examType === examType);
      const average =
        subset.length > 0
          ? Math.round(
              subset.reduce((a, b) => a + b.marks, 0) / subset.length,
            )
          : 0;
      return { examType, average };
    });
    return delay(result);
  },

  async comparison(): Promise<StudentWithMarks[]> {
    return delay(buildStudentsWithMarks());
  },
};
