import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ExamAverages } from "@/types";
import { ChartTooltip } from "./ChartTooltip";

const COLORS = ["#6366f1", "#a855f7", "#ec4899"];

interface PerformanceBarChartProps {
  data: ExamAverages[];
  height?: number;
}

export function PerformanceBarChart({ data, height = 320 }: PerformanceBarChartProps) {
  const chartData = data.map((item) => ({ name: item.examType, average: item.average }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
        <defs>
          {COLORS.map((color, index) => (
            <linearGradient key={color} id={`bar-${index}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.95} />
              <stop offset="100%" stopColor={color} stopOpacity={0.45} />
            </linearGradient>
          ))}
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis
          dataKey="name"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
        />
        <YAxis
          domain={[0, 100]}
          tickLine={false}
          axisLine={false}
          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
        />
        <Tooltip
          cursor={{ fill: "hsl(var(--muted) / 0.4)", radius: 8 }}
          content={<ChartTooltip unit=" / 100 avg" />}
        />
        <Legend
          formatter={() => (
            <span className="text-xs text-muted-foreground">Average score</span>
          )}
        />
        <Bar dataKey="average" name="Average score" radius={[8, 8, 0, 0]} maxBarSize={72} animationDuration={900}>
          {chartData.map((_, index) => (
            <Cell key={index} fill={`url(#bar-${index % COLORS.length})`} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
