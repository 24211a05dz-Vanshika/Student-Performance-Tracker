import type { TooltipProps } from "recharts";

/**
 * Recharts' ValueType/NameType live in a deep internal path that has moved
 * between versions; we redeclare the public shapes locally to stay version-safe.
 */
type ValueType = string | number | Array<string | number>;
type NameType = string | number;

interface ChartTooltipProps extends TooltipProps<ValueType, NameType> {
  unit?: string;
}

export function ChartTooltip({ active, payload, label, unit = "" }: ChartTooltipProps) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-border bg-popover/95 px-3 py-2 shadow-glow backdrop-blur-xl">
      <p className="mb-1 text-xs font-semibold text-foreground">{label}</p>
      {payload.map((entry) => (
        <div key={String(entry.dataKey)} className="flex items-center gap-2 text-xs">
          <span
            className="size-2.5 rounded-full"
            style={{ backgroundColor: entry.color ?? "hsl(var(--primary))" }}
          />
          <span className="text-muted-foreground">{entry.name}:</span>
          <span className="font-semibold text-foreground">
            {String(entry.value)}
            {unit}
          </span>
        </div>
      ))}
    </div>
  );
}
