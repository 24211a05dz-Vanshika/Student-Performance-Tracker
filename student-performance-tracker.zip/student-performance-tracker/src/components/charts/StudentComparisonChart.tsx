import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { StudentWithMarks } from "@/types";
import { ChartTooltip } from "./ChartTooltip";

interface StudentComparisonChartProps {
  data: StudentWithMarks[];
  height?: number;
}

export function StudentComparisonChart({ data, height = 360 }: StudentComparisonChartProps) {
  const chartData = data.map((student) => ({
    name: student.name.split(" ")[0],
    Midterm: student.marks.Midterm ?? 0,
    Final: student.marks.Final ?? 0,
    Quarterly: student.marks.Quarterly ?? 0,
  }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: -16, bottom: 0 }} barGap={2}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
        <XAxis
          dataKey="name"
          tickLine={false}
          axisLine={false}
          interval={0}
          angle={-25}
          textAnchor="end"
          height={56}
          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
        />
        <YAxis
          domain={[0, 100]}
          tickLine={false}
          axisLine={false}
          tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
        />
        <Tooltip cursor={{ fill: "hsl(var(--muted) / 0.4)" }} content={<ChartTooltip />} />
        <Legend
          formatter={(value) => <span className="text-xs text-muted-foreground">{value}</span>}
        />
        <Bar dataKey="Midterm" fill="#6366f1" radius={[6, 6, 0, 0]} maxBarSize={28} />
        <Bar dataKey="Final" fill="#a855f7" radius={[6, 6, 0, 0]} maxBarSize={28} />
        <Bar dataKey="Quarterly" fill="#ec4899" radius={[6, 6, 0, 0]} maxBarSize={28} />
      </BarChart>
    </ResponsiveContainer>
  );
}
