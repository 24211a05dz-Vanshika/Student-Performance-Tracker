import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import { Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FormInput } from "@/components/forms/FormInput";
import { FormSelect } from "@/components/forms/FormSelect";
import { EXAM_OPTIONS, MAX_MARK, MIN_MARK } from "@/constants";
import { markSchema, type MarkFormValues } from "@/validations/mark.schema";
import type { ExamType, SelectOption } from "@/types";

interface MarkFormProps {
  studentOptions: SelectOption[];
  defaultStudentId?: string;
  lockStudent?: boolean;
  onSubmit: (values: { studentId: string; examType: ExamType; marks: number }) => Promise<void> | void;
  submitting?: boolean;
}

export function MarkForm({
  studentOptions,
  defaultStudentId = "",
  lockStudent = false,
  onSubmit,
  submitting = false,
}: MarkFormProps) {
  const {
    control,
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<MarkFormValues>({
    resolver: zodResolver(markSchema),
    defaultValues: {
      studentId: defaultStudentId,
      examType: "Midterm",
      marks: 0,
    },
  });

  const submit = handleSubmit(async (values) => {
    await onSubmit({
      studentId: values.studentId,
      examType: values.examType as ExamType,
      marks: values.marks,
    });
    reset({ studentId: values.studentId, examType: values.examType, marks: 0 });
  });

  return (
    <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
      <Controller
        control={control}
        name="studentId"
        render={({ field }) => (
          <FormSelect
            label="Student"
            options={studentOptions}
            value={field.value}
            onChange={field.onChange}
            onBlur={field.onBlur}
            placeholder="Select student"
            error={errors.studentId?.message}
            disabled={lockStudent}
          />
        )}
      />
      <Controller
        control={control}
        name="examType"
        render={({ field }) => (
          <FormSelect
            label="Exam type"
            options={EXAM_OPTIONS}
            value={field.value}
            onChange={field.onChange}
            onBlur={field.onBlur}
            placeholder="Select exam"
            error={errors.examType?.message}
          />
        )}
      />
      <FormInput<MarkFormValues>
        label="Marks"
        name="marks"
        type="number"
        min={MIN_MARK}
        max={MAX_MARK}
        register={register}
        error={errors.marks}
        hint={`Enter a value between ${MIN_MARK} and ${MAX_MARK}`}
      />
      <div className="flex items-end">
        <Button type="submit" variant="gradient" className="w-full" loading={submitting}>
          <Save /> Save marks
        </Button>
      </div>
    </form>
  );
}
