import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import { Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FormInput } from "@/components/forms/FormInput";
import { FormSelect } from "@/components/forms/FormSelect";
import { CLASS_OPTIONS } from "@/constants";
import { studentSchema, type StudentFormValues } from "@/validations/student.schema";

interface StudentFormProps {
  defaultValues?: Partial<StudentFormValues>;
  onSubmit: (values: StudentFormValues) => Promise<void> | void;
  onCancel: () => void;
  submitting?: boolean;
  submitLabel?: string;
}

export function StudentForm({
  defaultValues,
  onSubmit,
  onCancel,
  submitting = false,
  submitLabel = "Save student",
}: StudentFormProps) {
  const {
    control,
    register,
    handleSubmit,
    formState: { errors, isDirty },
  } = useForm<StudentFormValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: {
      name: defaultValues?.name ?? "",
      admissionNumber: defaultValues?.admissionNumber ?? "",
      class: defaultValues?.class ?? "",
    },
  });

  return (
    <form
      onSubmit={handleSubmit((values) => onSubmit(values))}
      className="space-y-6"
      noValidate
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <FormInput<StudentFormValues>
            label="Full name"
            name="name"
            placeholder="e.g. Aanya Sharma"
            register={register}
            error={errors.name}
            autoComplete="off"
          />
        </div>
        <FormInput<StudentFormValues>
          label="Admission number"
          name="admissionNumber"
          placeholder="e.g. ADM-1024"
          register={register}
          error={errors.admissionNumber}
          hint="Letters, numbers and dashes only"
          autoComplete="off"
        />
        <Controller
          control={control}
          name="class"
          render={({ field }) => (
            <FormSelect
              label="Class"
              options={CLASS_OPTIONS}
              value={field.value}
              onChange={field.onChange}
              onBlur={field.onBlur}
              placeholder="Select class"
              error={errors.class?.message}
            />
          )}
        />
      </div>

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button type="button" variant="outline" onClick={onCancel} disabled={submitting}>
          <X /> Cancel
        </Button>
        <Button
          type="submit"
          variant="gradient"
          loading={submitting}
          disabled={submitting || (Boolean(defaultValues) && !isDirty)}
        >
          <Save /> {submitLabel}
        </Button>
      </div>
    </form>
  );
}
