import { useId } from "react";
import {
  type FieldValues,
  type FieldPath,
  type UseFormRegister,
  type FieldError,
} from "react-hook-form";
import { AlertCircle } from "lucide-react";
import { Input, type InputProps } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

interface FormInputProps<T extends FieldValues> extends Omit<InputProps, "name"> {
  label: string;
  name: FieldPath<T>;
  register: UseFormRegister<T>;
  error?: FieldError;
  hint?: string;
  endAdornment?: React.ReactNode;
}

export function FormInput<T extends FieldValues>({
  label,
  name,
  register,
  error,
  hint,
  endAdornment,
  className,
  ...props
}: FormInputProps<T>) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;

  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          aria-invalid={Boolean(error)}
          aria-describedby={error ? errorId : hint ? hintId : undefined}
          className={cn(endAdornment && "pr-10", className)}
          {...register(name)}
          {...props}
        />
        {endAdornment && (
          <div className="absolute right-1 top-1/2 -translate-y-1/2">{endAdornment}</div>
        )}
      </div>
      {error ? (
        <p id={errorId} className="flex items-center gap-1 text-xs font-medium text-destructive">
          <AlertCircle className="size-3.5" />
          {error.message}
        </p>
      ) : hint ? (
        <p id={hintId} className="text-xs text-muted-foreground">
          {hint}
        </p>
      ) : null}
    </div>
  );
}
