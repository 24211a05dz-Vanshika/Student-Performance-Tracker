import { useId } from "react";
import {
  type FieldValues,
  type FieldPath,
  type UseFormRegister,
  type FieldError,
} from "react-hook-form";
import { AlertCircle } from "lucide-react";
import { Textarea, type TextareaProps } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface FormTextareaProps<T extends FieldValues>
  extends Omit<TextareaProps, "name"> {
  label: string;
  name: FieldPath<T>;
  register: UseFormRegister<T>;
  error?: FieldError;
  hint?: string;
}

export function FormTextarea<T extends FieldValues>({
  label,
  name,
  register,
  error,
  hint,
  ...props
}: FormTextareaProps<T>) {
  const id = useId();
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      <Textarea id={id} aria-invalid={Boolean(error)} {...register(name)} {...props} />
      {error ? (
        <p className="flex items-center gap-1 text-xs font-medium text-destructive">
          <AlertCircle className="size-3.5" />
          {error.message}
        </p>
      ) : hint ? (
        <p className="text-xs text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  );
}
