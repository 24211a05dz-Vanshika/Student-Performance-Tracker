import type { LucideIcon } from "lucide-react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type Accent = "primary" | "violet" | "emerald" | "amber";

const ACCENTS: Record<Accent, { icon: string; glow: string }> = {
  primary: { icon: "from-primary/20 to-primary/5 text-primary", glow: "group-hover:shadow-glow" },
  violet: { icon: "from-violet-500/20 to-violet-500/5 text-violet-500", glow: "" },
  emerald: { icon: "from-emerald-500/20 to-emerald-500/5 text-emerald-500", glow: "" },
  amber: { icon: "from-amber-500/20 to-amber-500/5 text-amber-500", glow: "" },
};

interface StatsCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  accent?: Accent;
  trend?: { value: number; label?: string };
  className?: string;
}

export function StatsCard({
  label,
  value,
  icon: Icon,
  accent = "primary",
  trend,
  className,
}: StatsCardProps) {
  const positive = (trend?.value ?? 0) >= 0;
  const accentClasses = ACCENTS[accent];

  return (
    <Card
      className={cn(
        "group relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-glow",
        className,
      )}
    >
      <div className="pointer-events-none absolute -right-8 -top-8 size-28 rounded-full bg-gradient-to-br from-primary/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      <CardContent className="space-y-4 p-6">
        <div className="flex items-center justify-between">
          <div
            className={cn(
              "flex size-11 items-center justify-center rounded-xl bg-gradient-to-br shadow-soft",
              accentClasses.icon,
            )}
          >
            <Icon className="size-5" />
          </div>
          {trend && (
            <span
              className={cn(
                "inline-flex items-center gap-0.5 rounded-full px-2 py-0.5 text-xs font-semibold",
                positive ? "bg-success/12 text-success" : "bg-destructive/12 text-destructive",
              )}
            >
              {positive ? (
                <ArrowUpRight className="size-3.5" />
              ) : (
                <ArrowDownRight className="size-3.5" />
              )}
              {Math.abs(trend.value)}%
            </span>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-3xl font-bold tracking-tight">{value}</p>
          <p className="text-sm text-muted-foreground">
            {label}
            {trend?.label && (
              <span className="ml-1 text-muted-foreground/70">· {trend.label}</span>
            )}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
