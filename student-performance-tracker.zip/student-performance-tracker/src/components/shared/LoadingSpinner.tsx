import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  className?: string;
  label?: string;
  fullscreen?: boolean;
}

export function LoadingSpinner({ className, label, fullscreen }: LoadingSpinnerProps) {
  const content = (
    <div className="flex flex-col items-center gap-3 text-muted-foreground">
      <Loader2 className={cn("size-7 animate-spin text-primary", className)} />
      {label && <p className="text-sm font-medium">{label}</p>}
    </div>
  );

  if (fullscreen) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-background">
        {content}
      </div>
    );
  }
  return <div className="flex w-full items-center justify-center py-16">{content}</div>;
}
