import { GraduationCap } from "lucide-react";
import { APP_NAME, APP_TAGLINE } from "@/constants";
import { cn } from "@/lib/utils";

interface LogoProps {
  showText?: boolean;
  className?: string;
}

export function Logo({ showText = true, className }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <div className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary via-violet-500 to-fuchsia-500 text-white shadow-glow">
        <GraduationCap className="size-5" />
      </div>
      {showText && (
        <div className="leading-tight">
          <p className="text-sm font-bold tracking-tight">{APP_NAME}</p>
          <p className="text-[11px] text-muted-foreground">{APP_TAGLINE}</p>
        </div>
      )}
    </div>
  );
}
