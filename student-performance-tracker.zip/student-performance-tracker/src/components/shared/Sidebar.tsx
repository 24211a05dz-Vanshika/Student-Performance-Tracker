import { NavLink } from "react-router-dom";
import { ChevronLeft, Sparkles } from "lucide-react";
import { NAV_ITEMS } from "@/constants";
import { Logo } from "@/components/shared/Logo";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ collapsed, onToggleCollapse }: SidebarProps) {
  return (
    <aside
      className={cn(
        "fixed inset-y-0 left-0 z-30 hidden flex-col border-r border-border bg-card/60 backdrop-blur-xl transition-[width] duration-300 ease-in-out lg:flex",
        collapsed ? "w-[78px]" : "w-64",
      )}
    >
      <div className={cn("flex h-16 items-center border-b border-border px-4", collapsed && "justify-center")}>
        <Logo showText={!collapsed} />
      </div>

      <nav className="flex-1 space-y-1 p-3">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              cn(
                "group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200",
                collapsed && "justify-center",
                isActive
                  ? "bg-gradient-to-r from-primary/15 to-violet-500/10 text-primary shadow-soft"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground",
              )
            }
            title={collapsed ? item.label : undefined}
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <span className="absolute left-0 h-6 w-1 rounded-r-full bg-gradient-to-b from-primary to-violet-500" />
                )}
                <item.icon className="size-5 shrink-0" />
                {!collapsed && <span>{item.label}</span>}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {!collapsed && (
        <div className="p-3">
          <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-primary via-violet-500 to-fuchsia-500 p-4 text-white shadow-glow">
            <Sparkles className="mb-2 size-5" />
            <p className="text-sm font-semibold">Term insights</p>
            <p className="mt-0.5 text-xs text-white/80">
              Track every student's progress across all exams in one place.
            </p>
          </div>
        </div>
      )}

      <div className="border-t border-border p-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggleCollapse}
          className={cn("w-full text-muted-foreground", collapsed && "px-0")}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronLeft className={cn("transition-transform", collapsed && "rotate-180")} />
          {!collapsed && <span>Collapse</span>}
        </Button>
      </div>
    </aside>
  );
}
