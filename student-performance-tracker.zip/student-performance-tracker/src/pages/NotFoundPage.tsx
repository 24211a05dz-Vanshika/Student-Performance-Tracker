import { Link } from "react-router-dom";
import { Compass, Home } from "lucide-react";
import { Button } from "@/components/ui/button";

export function NotFoundPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 bg-background px-6 text-center">
      <div className="flex size-20 items-center justify-center rounded-3xl bg-gradient-to-br from-primary via-violet-500 to-fuchsia-500 text-white shadow-glow">
        <Compass className="size-10" />
      </div>
      <div className="space-y-2">
        <p className="text-6xl font-bold tracking-tight text-gradient">404</p>
        <h1 className="text-xl font-semibold">Page not found</h1>
        <p className="max-w-sm text-sm text-muted-foreground">
          The page you're looking for doesn't exist or may have been moved.
        </p>
      </div>
      <Button asChild variant="gradient">
        <Link to="/dashboard">
          <Home /> Back to dashboard
        </Link>
      </Button>
    </div>
  );
}
