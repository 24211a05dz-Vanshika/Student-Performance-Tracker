import { Link } from "react-router-dom";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  BarChart3,
  Crown,
  Lightbulb,
  Plus,
  Sigma,
  Users,
} from "lucide-react";
import { useAnalyticsSummary, useExamAverages, useStudentComparison } from "@/hooks/useAnalytics";
import { gradeFromScore } from "@/utils/format";
import { PageContainer } from "@/components/shared/PageContainer";
import { StatsCard } from "@/components/shared/StatsCard";
import { ChartCard } from "@/components/shared/ChartCard";
import { ChartSkeleton, StatsCardSkeleton } from "@/components/shared/SkeletonLoader";
import { ErrorState } from "@/components/shared/ErrorState";
import { EmptyState } from "@/components/shared/EmptyState";
import { PerformanceBarChart } from "@/components/charts/PerformanceBarChart";
import { StudentComparisonChart } from "@/components/charts/StudentComparisonChart";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function AnalyticsPage() {
  const summary = useAnalyticsSummary();
  const averages = useExamAverages();
  const comparison = useStudentComparison();

  const hasData = (averages.data?.some((a) => a.average > 0)) ?? false;

  const insights = (() => {
    if (!averages.data || !summary.data) return [];
    const sorted = [...averages.data].sort((a, b) => b.average - a.average);
    const best = sorted[0];
    const weakest = sorted[sorted.length - 1];
    const list: string[] = [];
    if (best && best.average > 0)
      list.push(`${best.examType} is the strongest exam with a ${best.average} average.`);
    if (weakest && weakest.average > 0 && weakest.examType !== best?.examType)
      list.push(`${weakest.examType} has the most room to improve at ${weakest.average} average.`);
    if (summary.data.topStudent)
      list.push(`${summary.data.topStudent.name} leads the cohort with a ${summary.data.topStudent.average} average.`);
    if (summary.data.averageScore !== null)
      list.push(`The overall cohort average across all exams is ${summary.data.averageScore}.`);
    return list;
  })();

  return (
    <PageContainer
      title="Analytics"
      description="Performance insights across your entire roster."
      actions={
        <Button asChild variant="outline">
          <Link to="/students">
            <Users /> View students
          </Link>
        </Button>
      }
    >
      {/* Summary metrics */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {summary.isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <StatsCardSkeleton key={i} />)
        ) : summary.isError || !summary.data ? (
          <div className="sm:col-span-2 xl:col-span-4">
            <ErrorState onRetry={() => void summary.refetch()} />
          </div>
        ) : (
          <>
            <StatsCard label="Highest score" value={summary.data.highestScore ?? "—"} icon={ArrowUp} accent="emerald" />
            <StatsCard label="Lowest score" value={summary.data.lowestScore ?? "—"} icon={ArrowDown} accent="amber" />
            <StatsCard label="Average score" value={summary.data.averageScore ?? "—"} icon={Sigma} accent="primary" />
            <StatsCard label="Top performer" value={summary.data.topStudent?.name.split(" ")[0] ?? "—"} icon={Crown} accent="violet" />
          </>
        )}
      </div>

      {!hasData && !averages.isLoading ? (
        <EmptyState
          icon={BarChart3}
          title="Not enough data yet"
          description="Add students and record their marks to unlock performance analytics."
          action={
            <Button asChild variant="gradient">
              <Link to="/students/new">
                <Plus /> Add student
              </Link>
            </Button>
          }
        />
      ) : (
        <>
          <div className="grid gap-6 lg:grid-cols-2">
            {averages.isLoading ? (
              <ChartSkeleton />
            ) : averages.isError || !averages.data ? (
              <ErrorState onRetry={() => void averages.refetch()} />
            ) : (
              <ChartCard
                title="Average by exam type"
                description="Mean score across all students for each exam"
              >
                <PerformanceBarChart data={averages.data} />
              </ChartCard>
            )}

            {/* Top performers list */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Crown className="size-4 text-amber-500" /> Leaderboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                {comparison.isLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="h-12 animate-pulse rounded-lg bg-muted/60" />
                    ))}
                  </div>
                ) : comparison.data ? (
                  <ol className="space-y-2">
                    {[...comparison.data]
                      .filter((s) => s.average !== null)
                      .sort((a, b) => (b.average ?? 0) - (a.average ?? 0))
                      .slice(0, 6)
                      .map((student, index) => (
                        <li
                          key={student.id}
                          className="flex items-center gap-3 rounded-lg border border-border/60 p-2.5"
                        >
                          <span
                            className={`flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                              index === 0
                                ? "bg-amber-400/20 text-amber-500"
                                : index === 1
                                  ? "bg-slate-400/20 text-slate-400"
                                  : index === 2
                                    ? "bg-orange-400/20 text-orange-500"
                                    : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {index + 1}
                          </span>
                          <Link
                            to={`/students/${student.id}`}
                            className="min-w-0 flex-1 truncate text-sm font-medium hover:text-primary hover:underline"
                          >
                            {student.name}
                          </Link>
                          <Badge variant={gradeFromScore(student.average ?? 0).tone}>
                            {student.average}
                          </Badge>
                        </li>
                      ))}
                  </ol>
                ) : null}
              </CardContent>
            </Card>
          </div>

          {/* Student comparison (full width) */}
          {comparison.isLoading ? (
            <ChartSkeleton />
          ) : comparison.isError || !comparison.data ? (
            <ErrorState onRetry={() => void comparison.refetch()} />
          ) : (
            <ChartCard
              title="Student comparison"
              description="Per-student breakdown across Midterm, Final and Quarterly exams"
            >
              <StudentComparisonChart data={comparison.data} />
            </ChartCard>
          )}

          {/* Insights */}
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Lightbulb className="size-4 text-primary" /> Performance insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2">
                {insights.map((insight) => (
                  <div
                    key={insight}
                    className="flex items-start gap-3 rounded-xl border border-border bg-gradient-to-br from-primary/5 to-transparent p-4"
                  >
                    <Activity className="mt-0.5 size-4 shrink-0 text-primary" />
                    <p className="text-sm text-muted-foreground">{insight}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </PageContainer>
  );
}
