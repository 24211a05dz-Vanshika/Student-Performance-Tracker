import { useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  ArrowLeft,
  BookOpen,
  Hash,
  Pencil,
  TrendingUp,
  Trash2,
  Trophy,
} from "lucide-react";
import { EXAM_TYPES } from "@/constants";
import { useDeleteStudent, useStudent } from "@/hooks/useStudents";
import { useStudentMarks, useUpsertMark } from "@/hooks/useMarks";
import { toast } from "@/lib/toast";
import { gradeFromScore, getInitials } from "@/utils/format";
import type { ExamType } from "@/types";
import { PageContainer } from "@/components/shared/PageContainer";
import { DetailSkeleton } from "@/components/shared/SkeletonLoader";
import { ErrorState } from "@/components/shared/ErrorState";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { MarkForm } from "@/components/forms/MarkForm";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const EXAM_ACCENT: Record<ExamType, string> = {
  Midterm: "from-indigo-500/15 to-indigo-500/5 text-indigo-500",
  Final: "from-violet-500/15 to-violet-500/5 text-violet-500",
  Quarterly: "from-fuchsia-500/15 to-fuchsia-500/5 text-fuchsia-500",
};

export function StudentDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: student, isLoading, isError, refetch } = useStudent(id);
  const marksQuery = useStudentMarks(id);
  const upsertMark = useUpsertMark();
  const deleteStudent = useDeleteStudent();
  const [confirmOpen, setConfirmOpen] = useState(false);

  const marksMap = useMemo(() => {
    const map = Object.fromEntries(EXAM_TYPES.map((e) => [e, null])) as Record<
      ExamType,
      number | null
    >;
    marksQuery.data?.forEach((mark) => {
      map[mark.examType] = mark.marks;
    });
    return map;
  }, [marksQuery.data]);

  const recorded = Object.values(marksMap).filter((v): v is number => v !== null);
  const average =
    recorded.length > 0
      ? Math.round(recorded.reduce((a, b) => a + b, 0) / recorded.length)
      : null;

  const handleSaveMark = async (values: {
    studentId: string;
    examType: ExamType;
    marks: number;
  }) => {
    try {
      await upsertMark.mutateAsync(values);
      toast.success("Marks saved", `${values.examType} score updated to ${values.marks}.`);
    } catch {
      toast.error("Could not save marks", "Please try again.");
    }
  };

  const handleDelete = async () => {
    if (!student) return;
    try {
      await deleteStudent.mutateAsync(student.id);
      toast.success("Student removed", `${student.name} has been deleted.`);
      navigate("/students");
    } catch {
      toast.error("Delete failed", "Please try again.");
    }
  };

  if (isLoading) {
    return (
      <PageContainer title="Student details">
        <DetailSkeleton />
      </PageContainer>
    );
  }

  if (isError || !student) {
    return (
      <PageContainer
        title="Student details"
        actions={
          <Button asChild variant="outline">
            <Link to="/students">
              <ArrowLeft /> Back
            </Link>
          </Button>
        }
      >
        <ErrorState title="Student not found" message="This student may have been removed." onRetry={() => void refetch()} />
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title="Student details"
      actions={
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link to="/students">
              <ArrowLeft /> Back
            </Link>
          </Button>
          <Button asChild variant="secondary">
            <Link to={`/students/${student.id}/edit`}>
              <Pencil /> Edit
            </Link>
          </Button>
          <Button variant="destructive" onClick={() => setConfirmOpen(true)}>
            <Trash2 /> Delete
          </Button>
        </div>
      }
    >
      {/* Hero profile */}
      <Card className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-fuchsia-500/10" />
        <div className="pointer-events-none absolute -right-12 -top-12 size-48 rounded-full bg-primary/10 blur-3xl" />
        <CardContent className="relative flex flex-col gap-6 p-6 sm:flex-row sm:items-center sm:p-8">
          <Avatar className="size-20 ring-4 ring-background">
            <AvatarFallback className="text-2xl">{getInitials(student.name)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-3">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">{student.name}</h2>
              <div className="mt-1.5 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1.5">
                  <Hash className="size-4" /> {student.admissionNumber}
                </span>
                <Separator orientation="vertical" className="h-4" />
                <Badge variant="secondary">{student.class}</Badge>
              </div>
            </div>
          </div>
          {average !== null && (
            <div className="rounded-xl border border-border bg-card/60 p-4 text-center backdrop-blur-sm">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Overall average
              </p>
              <p className="mt-1 text-3xl font-bold text-gradient">{average}</p>
              <Badge variant={gradeFromScore(average).tone} className="mt-1">
                {gradeFromScore(average).label}
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Marks cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        {marksQuery.isLoading
          ? EXAM_TYPES.map((exam) => (
              <Card key={exam}>
                <CardContent className="p-6">
                  <div className="h-24 animate-pulse rounded-lg bg-muted/60" />
                </CardContent>
              </Card>
            ))
          : EXAM_TYPES.map((exam) => {
              const score = marksMap[exam];
              return (
                <Card key={exam} className="group transition-all hover:-translate-y-1 hover:shadow-glow">
                  <CardContent className="space-y-3 p-6">
                    <div className="flex items-center justify-between">
                      <span
                        className={`flex size-10 items-center justify-center rounded-xl bg-gradient-to-br ${EXAM_ACCENT[exam]}`}
                      >
                        <BookOpen className="size-5" />
                      </span>
                      {score !== null && (
                        <Badge variant={gradeFromScore(score).tone}>
                          {gradeFromScore(score).label}
                        </Badge>
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">{exam}</p>
                      <p className="text-3xl font-bold tracking-tight">
                        {score !== null ? score : "—"}
                        {score !== null && (
                          <span className="text-base font-medium text-muted-foreground"> / 100</span>
                        )}
                      </p>
                    </div>
                    {score !== null ? (
                      <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-primary to-violet-500 transition-all duration-700"
                          style={{ width: `${score}%` }}
                        />
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground">No marks recorded yet</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
      </div>

      {/* Stats row + Marks entry */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="size-4 text-primary" /> Performance summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Highest</span>
              <span className="font-semibold">{recorded.length ? Math.max(...recorded) : "—"}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Lowest</span>
              <span className="font-semibold">{recorded.length ? Math.min(...recorded) : "—"}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Average</span>
              <span className="font-semibold">{average ?? "—"}</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Exams recorded</span>
              <span className="inline-flex items-center gap-1 font-semibold">
                <Trophy className="size-3.5 text-amber-500" /> {recorded.length} / {EXAM_TYPES.length}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Enter or update marks</CardTitle>
            <CardDescription>
              Record a score (0–100) for this student. Saving an existing exam updates it.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <MarkForm
              studentOptions={[{ label: student.name, value: student.id }]}
              defaultStudentId={student.id}
              lockStudent
              onSubmit={handleSaveMark}
              submitting={upsertMark.isPending}
            />
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="Delete student?"
        description={`This will permanently remove ${student.name} and all associated marks.`}
        confirmLabel="Delete"
        destructive
        loading={deleteStudent.isPending}
        onConfirm={handleDelete}
      />
    </PageContainer>
  );
}
