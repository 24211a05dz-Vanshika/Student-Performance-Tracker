import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useCreateStudent } from "@/hooks/useStudents";
import { toast } from "@/lib/toast";
import type { StudentFormValues } from "@/validations/student.schema";
import { PageContainer } from "@/components/shared/PageContainer";
import { StudentForm } from "@/components/forms/StudentForm";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function CreateStudentPage() {
  const navigate = useNavigate();
  const createStudent = useCreateStudent();

  const handleSubmit = async (values: StudentFormValues) => {
    try {
      const student = await createStudent.mutateAsync(values);
      toast.success("Student created", `${student.name} has been added to your roster.`);
      navigate(`/students/${student.id}`);
    } catch (error) {
      toast.error(
        "Could not create student",
        error instanceof Error ? error.message : "Please try again.",
      );
    }
  };

  return (
    <PageContainer
      title="Add student"
      description="Create a new student record. You can add their marks afterwards."
      actions={
        <Button asChild variant="outline">
          <Link to="/students">
            <ArrowLeft /> Back to students
          </Link>
        </Button>
      }
    >
      <Card className="mx-auto w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Student details</CardTitle>
          <CardDescription>All fields are required.</CardDescription>
        </CardHeader>
        <CardContent>
          <StudentForm
            onSubmit={handleSubmit}
            onCancel={() => navigate("/students")}
            submitting={createStudent.isPending}
            submitLabel="Create student"
          />
        </CardContent>
      </Card>
    </PageContainer>
  );
}
