import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Eye,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Trash2,
  Users,
} from "lucide-react";
import { DEFAULT_PAGE_SIZE } from "@/constants";
import { useDebounce } from "@/hooks/useDebounce";
import { useDeleteStudent, useStudents } from "@/hooks/useStudents";
import { toast } from "@/lib/toast";
import { getInitials } from "@/utils/format";
import type { Student } from "@/types";
import { PageContainer } from "@/components/shared/PageContainer";
import { SearchInput } from "@/components/shared/SearchInput";
import { DataTable, type Column } from "@/components/shared/DataTable";
import { Pagination } from "@/components/shared/Pagination";
import { EmptyState } from "@/components/shared/EmptyState";
import { ErrorState } from "@/components/shared/ErrorState";
import { ConfirmDialog } from "@/components/shared/ConfirmDialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function StudentsPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const debouncedSearch = useDebounce(search, 350);
  const [target, setTarget] = useState<Student | null>(null);

  const params = useMemo(
    () => ({ page, pageSize: DEFAULT_PAGE_SIZE, search: debouncedSearch }),
    [page, debouncedSearch],
  );
  const { data, isLoading, isError, isFetching, refetch } = useStudents(params);
  const deleteStudent = useDeleteStudent();

  const handleSearch = (value: string) => {
    setSearch(value);
    setPage(1);
  };

  const handleDelete = async () => {
    if (!target) return;
    try {
      await deleteStudent.mutateAsync(target.id);
      toast.success("Student removed", `${target.name} has been deleted.`);
      setTarget(null);
    } catch {
      toast.error("Delete failed", "Could not remove the student. Please try again.");
    }
  };

  const columns: Column<Student>[] = [
    {
      key: "name",
      header: "Student",
      cell: (student) => (
        <div className="flex items-center gap-3">
          <Avatar className="size-9">
            <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
          </Avatar>
          <span className="font-medium">{student.name}</span>
        </div>
      ),
    },
    {
      key: "admissionNumber",
      header: "Admission no.",
      cell: (student) => (
        <span className="font-mono text-sm text-muted-foreground">
          {student.admissionNumber}
        </span>
      ),
    },
    {
      key: "class",
      header: "Class",
      cell: (student) => <Badge variant="secondary">{student.class}</Badge>,
    },
    {
      key: "actions",
      header: <span className="sr-only">Actions</span>,
      headClassName: "text-right",
      className: "text-right",
      cell: (student) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="size-8" aria-label="Open actions">
              <MoreHorizontal />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => navigate(`/students/${student.id}`)}>
              <Eye /> View details
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate(`/students/${student.id}/edit`)}>
              <Pencil /> Edit
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem destructive onClick={() => setTarget(student)}>
              <Trash2 /> Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  return (
    <PageContainer
      title="Students"
      description="Manage your roster — search, view, edit and remove student records."
      actions={
        <Button asChild variant="gradient">
          <Link to="/students/new">
            <Plus /> Add student
          </Link>
        </Button>
      }
    >
      <Card>
        <CardContent className="space-y-4 p-4 sm:p-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <SearchInput
              value={search}
              onChange={handleSearch}
              placeholder="Search by name, admission no. or class…"
            />
            {data && (
              <p className="text-sm text-muted-foreground">
                {data.total} {data.total === 1 ? "student" : "students"}
                {isFetching && <span className="ml-2 animate-pulse">· updating…</span>}
              </p>
            )}
          </div>

          {isError ? (
            <ErrorState onRetry={() => void refetch()} />
          ) : (
            <DataTable<Student>
              columns={columns}
              data={data?.data ?? []}
              rowKey={(student) => student.id}
              isLoading={isLoading}
              skeletonRows={DEFAULT_PAGE_SIZE}
              onRowClick={(student) => navigate(`/students/${student.id}`)}
              emptyState={
                debouncedSearch ? (
                  <EmptyState
                    icon={Search}
                    title="No matches found"
                    description={`No students match "${debouncedSearch}". Try a different search.`}
                    className="border-0"
                  />
                ) : (
                  <EmptyState
                    icon={Users}
                    title="No students yet"
                    description="Add your first student to start tracking performance."
                    className="border-0"
                    action={
                      <Button asChild variant="gradient">
                        <Link to="/students/new">
                          <Plus /> Add student
                        </Link>
                      </Button>
                    }
                  />
                )
              }
            />
          )}

          {data && data.total > 0 && (
            <Pagination
              page={data.page}
              totalPages={data.totalPages}
              total={data.total}
              pageSize={data.pageSize}
              onPageChange={setPage}
            />
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={Boolean(target)}
        onOpenChange={(open) => !open && setTarget(null)}
        title="Delete student?"
        description={`This will permanently remove ${target?.name ?? "this student"} and all associated marks. This action cannot be undone.`}
        confirmLabel="Delete"
        destructive
        loading={deleteStudent.isPending}
        onConfirm={handleDelete}
      />
    </PageContainer>
  );
}

