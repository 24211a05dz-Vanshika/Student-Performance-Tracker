import { useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import { Eye, EyeOff, LogIn, Lock, Mail, Sparkles } from "lucide-react";
import { APP_NAME, DEMO_CREDENTIALS } from "@/constants";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "@/lib/toast";
import { AuthError } from "@/services/auth.service";
import { loginSchema, type LoginFormValues } from "@/validations/auth.schema";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { FormInput } from "@/components/forms/FormInput";

interface LocationState {
  from?: { pathname?: string };
}

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "", remember: true },
  });

  const onSubmit = handleSubmit(async (values) => {
    try {
      await login(values);
      const from = (location.state as LocationState | null)?.from?.pathname ?? "/dashboard";
      toast.success("Welcome back!", "You're now signed in to Scholar.");
      navigate(from, { replace: true });
    } catch (error) {
      const message =
        error instanceof AuthError
          ? error.message
          : "Unable to sign in right now. Please try again.";
      toast.error("Sign in failed", message);
    }
  });

  const fillDemo = () => {
    setValue("email", DEMO_CREDENTIALS.email, { shouldValidate: true });
    setValue("password", DEMO_CREDENTIALS.password, { shouldValidate: true });
  };

  return (
    <div className="animate-scale-in space-y-8">
      <div className="space-y-2 text-center lg:hidden">
        <h1 className="text-2xl font-bold">{APP_NAME}</h1>
      </div>

      <div className="space-y-2">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Sign in</h2>
        <p className="text-sm text-muted-foreground">
          Welcome back. Enter your credentials to access your dashboard.
        </p>
      </div>

      <div className="flex items-start gap-3 rounded-xl border border-primary/20 bg-primary/5 p-3.5">
        <Sparkles className="mt-0.5 size-4 shrink-0 text-primary" />
        <div className="flex-1 text-xs">
          <p className="font-semibold text-foreground">Demo credentials</p>
          <p className="mt-0.5 text-muted-foreground">
            {DEMO_CREDENTIALS.email} · {DEMO_CREDENTIALS.password}
          </p>
        </div>
        <Button type="button" variant="outline" size="sm" onClick={fillDemo}>
          Autofill
        </Button>
      </div>

      <form onSubmit={onSubmit} className="space-y-5" noValidate>
        <FormInput<LoginFormValues>
          label="Email address"
          name="email"
          type="email"
          placeholder="you@school.edu"
          register={register}
          error={errors.email}
          autoComplete="email"
          endAdornment={<Mail className="mr-2 size-4 text-muted-foreground" />}
        />

        <div className="space-y-1.5">
          <FormInput<LoginFormValues>
            label="Password"
            name="password"
            type={showPassword ? "text" : "password"}
            placeholder="••••••••"
            register={register}
            error={errors.password}
            autoComplete="current-password"
            endAdornment={
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="rounded-md p-2 text-muted-foreground transition-colors hover:text-foreground focus-ring"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            }
          />
        </div>

        <div className="flex items-center justify-between">
          <Controller
            control={control}
            name="remember"
            render={({ field }) => (
              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember"
                  checked={field.value}
                  onCheckedChange={(checked) => field.onChange(checked === true)}
                />
                <Label htmlFor="remember" className="cursor-pointer font-normal text-muted-foreground">
                  Remember me
                </Label>
              </div>
            )}
          />
          <Link to="#" className="text-sm font-medium text-primary hover:underline">
            Forgot password?
          </Link>
        </div>

        <Button type="submit" variant="gradient" size="lg" className="w-full" loading={isSubmitting}>
          {!isSubmitting && <LogIn />}
          Sign in
        </Button>
      </form>

      <p className="text-center text-sm text-muted-foreground">
        <Lock className="mr-1 inline size-3.5 align-text-bottom" />
        Protected demo environment — data is stored locally in your browser.
      </p>
    </div>
  );
}
