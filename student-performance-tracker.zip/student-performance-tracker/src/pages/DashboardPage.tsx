import { Link } from "react-router-dom";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  GraduationCap,
  Plus,
  Trophy,
  Users,
} from "lucide-react";
import { useDashboardStats, useRecentStudents } from "@/hooks/useDashboard";
import { useExamAverages } from "@/hooks/useAnalytics";
import { formatDate, getInitials } from "@/utils/format";
import { PageContainer } from "@/components/shared/PageContainer";
import { StatsCard } from "@/components/shared/StatsCard";
import { ChartCard } from "@/components/shared/ChartCard";
import { StatsCardSkeleton, ChartSkeleton } from "@/components/shared/SkeletonLoader";
import { ErrorState } from "@/components/shared/ErrorState";
import { EmptyState } from "@/components/shared/EmptyState";
import { PerformanceBarChart } from "@/components/charts/PerformanceBarChart";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const QUICK_ACTIONS = [
  { label: "Add a student", to: "/students/new", icon: Plus, desc: "Create a new roster entry" },
  { label: "View students", to: "/students", icon: Users, desc: "Browse and manage records" },
  { label: "Open analytics", to: "/analytics", icon: BarChart3, desc: "Explore performance insights" },
];

export function DashboardPage() {
  const stats = useDashboardStats();
  const recent = useRecentStudents(5);
  const averages = useExamAverages();

  return (
    <PageContainer
      title="Dashboard"
      description="A snapshot of your roster and exam activity this term."
      actions={
        <Button asChild variant="gradient">
          <Link to="/students/new">
            <Plus /> Add student
          </Link>
        </Button>
      }
    >
      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <StatsCardSkeleton key={i} />)
        ) : stats.isError || !stats.data ? (
          <div className="sm:col-span-2 xl:col-span-4">
            <ErrorState onRetry={() => void stats.refetch()} />
          </div>
        ) : (
          <>
            <StatsCard label="Total students" value={stats.data.totalStudents} icon={GraduationCap} accent="primary" trend={{ value: 12, label: "this term" }} />
            <StatsCard label="Midterm entries" value={stats.data.midtermEntries} icon={BookOpen} accent="violet" trend={{ value: 8 }} />
            <StatsCard label="Final entries" value={stats.data.finalEntries} icon={Trophy} accent="emerald" trend={{ value: 5 }} />
            <StatsCard label="Quarterly entries" value={stats.data.quarterlyEntries} icon={BarChart3} accent="amber" trend={{ value: -3 }} />
          </>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Overview analytics */}
        <div className="lg:col-span-2">
          {averages.isLoading ? (
            <ChartSkeleton />
          ) : averages.isError || !averages.data ? (
            <ErrorState onRetry={() => void averages.refetch()} />
          ) : (
            <ChartCard
              title="Performance overview"
              description="Average score across all students by exam type"
              actions={
                <Button asChild variant="ghost" size="sm">
                  <Link to="/analytics">
                    Details <ArrowRight />
                  </Link>
                </Button>
              }
            >
              <PerformanceBarChart data={averages.data} />
            </ChartCard>
          )}
        </div>

        {/* Quick actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick actions</CardTitle>
            <CardDescription>Jump straight to common tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {QUICK_ACTIONS.map((action) => (
              <Link
                key={action.to}
                to={action.to}
                className="group flex items-center gap-3 rounded-xl border border-border bg-card p-3 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-card"
              >
                <span className="flex size-10 items-center justify-center rounded-lg bg-gradient-to-br from-primary/15 to-violet-500/10 text-primary">
                  <action.icon className="size-5" />
                </span>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{action.label}</p>
                  <p className="text-xs text-muted-foreground">{action.desc}</p>
                </div>
                <ArrowRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
              </Link>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Recent students */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle>Recent students</CardTitle>
            <CardDescription>Newest additions to your roster</CardDescription>
          </div>
          <Button asChild variant="ghost" size="sm">
            <Link to="/students">
              View all <ArrowRight />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {recent.isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-14 animate-pulse rounded-xl bg-muted/60" />
              ))}
            </div>
          ) : recent.isError ? (
            <ErrorState onRetry={() => void recent.refetch()} />
          ) : recent.data && recent.data.length > 0 ? (
            <div className="divide-y divide-border">
              {recent.data.map((student) => (
                <Link
                  key={student.id}
                  to={`/students/${student.id}`}
                  className="flex items-center gap-3 py-3 transition-colors hover:bg-muted/30 -mx-2 px-2 rounded-lg"
                >
                  <Avatar>
                    <AvatarFallback>{getInitials(student.name)}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{student.name}</p>
                    <p className="text-xs text-muted-foreground">{student.admissionNumber}</p>
                  </div>
                  <Badge variant="secondary">{student.class}</Badge>
                  <span className="hidden text-xs text-muted-foreground sm:block">
                    {formatDate(student.createdAt)}
                  </span>
                </Link>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={Users}
              title="No students yet"
              description="Add your first student to get started."
              action={
                <Button asChild variant="gradient">
                  <Link to="/students/new">
                    <Plus /> Add student
                  </Link>
                </Button>
              }
            />
          )}
        </CardContent>
      </Card>
    </PageContainer>
  );
}
