import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useStudent, useUpdateStudent } from "@/hooks/useStudents";
import { toast } from "@/lib/toast";
import type { StudentFormValues } from "@/validations/student.schema";
import { PageContainer } from "@/components/shared/PageContainer";
import { StudentForm } from "@/components/forms/StudentForm";
import { LoadingSpinner } from "@/components/shared/LoadingSpinner";
import { ErrorState } from "@/components/shared/ErrorState";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function EditStudentPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: student, isLoading, isError, refetch } = useStudent(id);
  const updateStudent = useUpdateStudent();

  const handleSubmit = async (values: StudentFormValues) => {
    if (!id) return;
    try {
      await updateStudent.mutateAsync({ id, input: values });
      toast.success("Changes saved", "The student record has been updated.");
      navigate(`/students/${id}`);
    } catch (error) {
      toast.error(
        "Could not save changes",
        error instanceof Error ? error.message : "Please try again.",
      );
    }
  };

  return (
    <PageContainer
      title="Edit student"
      description="Update this student's record."
      actions={
        <Button asChild variant="outline">
          <Link to={id ? `/students/${id}` : "/students"}>
            <ArrowLeft /> Back
          </Link>
        </Button>
      }
    >
      <Card className="mx-auto w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Student details</CardTitle>
          <CardDescription>All fields are required.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <LoadingSpinner label="Loading student…" />
          ) : isError || !student ? (
            <ErrorState title="Student not found" onRetry={() => void refetch()} />
          ) : (
            <StudentForm
              defaultValues={{
                name: student.name,
                admissionNumber: student.admissionNumber,
                class: student.class,
              }}
              onSubmit={handleSubmit}
              onCancel={() => navigate(`/students/${student.id}`)}
              submitting={updateStudent.isPending}
              submitLabel="Save changes"
            />
          )}
        </CardContent>
      </Card>
    </PageContainer>
  );
}
