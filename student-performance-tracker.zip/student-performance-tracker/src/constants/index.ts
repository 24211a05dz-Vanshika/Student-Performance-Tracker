import type { ExamType, SelectOption } from "@/types";
import { LayoutDashboard, GraduationCap, BarChart3, type LucideIcon } from "lucide-react";

export const APP_NAME = "Scholar";
export const APP_TAGLINE = "Student Performance Tracker";

export const EXAM_TYPES: readonly ExamType[] = ["Midterm", "Final", "Quarterly"] as const;

export const EXAM_OPTIONS: SelectOption<ExamType>[] = EXAM_TYPES.map((e) => ({
  label: e,
  value: e,
}));

export const MIN_MARK = 0;
export const MAX_MARK = 100;

export const CLASS_OPTIONS: SelectOption[] = [
  "Grade 6",
  "Grade 7",
  "Grade 8",
  "Grade 9",
  "Grade 10",
  "Grade 11",
  "Grade 12",
].map((c) => ({ label: c, value: c }));

export const DEFAULT_PAGE_SIZE = 8;

export const DEMO_CREDENTIALS = {
  email: "admin@scholar.app",
  password: "password123",
} as const;

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
  { label: "Students", to: "/students", icon: GraduationCap },
  { label: "Analytics", to: "/analytics", icon: BarChart3 },
];

/** Centralised React Query keys for cache consistency. */
export const queryKeys = {
  auth: ["auth", "session"] as const,
  students: {
    all: ["students"] as const,
    list: (params: { page: number; pageSize: number; search?: string }) =>
      ["students", "list", params] as const,
    detail: (id: string) => ["students", "detail", id] as const,
  },
  marks: {
    all: ["marks"] as const,
    byStudent: (studentId: string) => ["marks", "student", studentId] as const,
  },
  dashboard: {
    stats: ["dashboard", "stats"] as const,
    recent: ["dashboard", "recent-students"] as const,
  },
  analytics: {
    summary: ["analytics", "summary"] as const,
    examAverages: ["analytics", "exam-averages"] as const,
    comparison: ["analytics", "comparison"] as const,
  },
} as const;

export const STORAGE_KEYS = {
  students: "spt::students",
  marks: "spt::marks",
  session: "spt::session",
  sidebarCollapsed: "spt::sidebar-collapsed",
} as const;
