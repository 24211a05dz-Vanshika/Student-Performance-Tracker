export { AppLayout as DashboardLayout } from "@/components/shared/AppLayout";
