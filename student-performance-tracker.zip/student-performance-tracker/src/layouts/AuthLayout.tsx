import { Outlet } from "react-router-dom";
import { GraduationCap, LineChart, ShieldCheck, Users } from "lucide-react";
import { APP_NAME } from "@/constants";
import { Logo } from "@/components/shared/Logo";

const HIGHLIGHTS = [
  { icon: Users, title: "Centralised roster", text: "Manage every student record from one elegant workspace." },
  { icon: LineChart, title: "Live analytics", text: "Visualise performance trends across all exam types instantly." },
  { icon: ShieldCheck, title: "Secure by design", text: "Protected routes keep academic data exactly where it belongs." },
];

export function AuthLayout() {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Branding / illustration panel */}
      <div className="relative hidden overflow-hidden bg-slate-950 lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-violet-600/20 to-fuchsia-600/20" />
        <div className="absolute -left-24 top-1/4 size-96 rounded-full bg-primary/30 blur-3xl" />
        <div className="absolute -right-16 bottom-1/4 size-96 rounded-full bg-fuchsia-500/20 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 bg-grid-faint bg-[size:40px_40px] opacity-20" />

        <div className="relative z-10">
          <Logo className="[&_p]:text-white" />
        </div>

        <div className="relative z-10 space-y-8 text-white">
          <div className="inline-flex size-16 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-xl ring-1 ring-white/20">
            <GraduationCap className="size-8" />
          </div>
          <div className="space-y-3">
            <h1 className="max-w-md text-4xl font-bold leading-tight tracking-tight">
              Every student's progress, beautifully tracked.
            </h1>
            <p className="max-w-md text-white/70">
              {APP_NAME} brings roster management, marks and analytics together in a
              single premium dashboard.
            </p>
          </div>
          <ul className="space-y-4">
            {HIGHLIGHTS.map((item) => (
              <li key={item.title} className="flex items-start gap-3">
                <span className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg bg-white/10 ring-1 ring-white/20">
                  <item.icon className="size-5" />
                </span>
                <div>
                  <p className="font-semibold">{item.title}</p>
                  <p className="text-sm text-white/65">{item.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative z-10 text-xs text-white/50">
          © {new Date().getFullYear()} {APP_NAME}. Crafted for educators.
        </p>
      </div>

      {/* Form panel */}
      <div className="flex items-center justify-center bg-background px-4 py-10 sm:px-8">
        <div className="w-full max-w-md">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
