import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants";
import { analyticsService } from "@/services/analytics.service";

export function useDashboardStats() {
  return useQuery({
    queryKey: queryKeys.dashboard.stats,
    queryFn: () => analyticsService.dashboardStats(),
  });
}

export function useRecentStudents(limit = 5) {
  return useQuery({
    queryKey: queryKeys.dashboard.recent,
    queryFn: () => analyticsService.recentStudents(limit),
  });
}
