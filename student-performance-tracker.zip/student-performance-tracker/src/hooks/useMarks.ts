import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { queryKeys } from "@/constants";
import { marksService } from "@/services/marks.service";
import type { MarkInput } from "@/types";

export function useStudentMarks(studentId: string | undefined) {
  return useQuery({
    queryKey: queryKeys.marks.byStudent(studentId ?? ""),
    queryFn: () => marksService.listByStudent(studentId as string),
    enabled: Boolean(studentId),
  });
}

export function useUpsertMark() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: MarkInput) => marksService.upsert(input),
    onSuccess: (mark) => {
      void queryClient.invalidateQueries({
        queryKey: queryKeys.marks.byStudent(mark.studentId),
      });
      void queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });
      void queryClient.invalidateQueries({ queryKey: ["analytics"] });
    },
  });
}
