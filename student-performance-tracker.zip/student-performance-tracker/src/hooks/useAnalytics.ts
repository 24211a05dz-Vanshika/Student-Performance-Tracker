import { useQuery } from "@tanstack/react-query";
import { queryKeys } from "@/constants";
import { analyticsService } from "@/services/analytics.service";

export function useAnalyticsSummary() {
  return useQuery({
    queryKey: queryKeys.analytics.summary,
    queryFn: () => analyticsService.summary(),
  });
}

export function useExamAverages() {
  return useQuery({
    queryKey: queryKeys.analytics.examAverages,
    queryFn: () => analyticsService.examAverages(),
  });
}

export function useStudentComparison() {
  return useQuery({
    queryKey: queryKeys.analytics.comparison,
    queryFn: () => analyticsService.comparison(),
  });
}
