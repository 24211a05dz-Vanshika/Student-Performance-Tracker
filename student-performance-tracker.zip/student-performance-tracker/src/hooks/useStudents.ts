import {
  keepPreviousData,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { queryKeys } from "@/constants";
import { studentsService } from "@/services/students.service";
import type { PaginationParams, StudentInput } from "@/types";

export function useStudents(params: PaginationParams) {
  return useQuery({
    queryKey: queryKeys.students.list(params),
    queryFn: () => studentsService.list(params),
    placeholderData: keepPreviousData,
  });
}

export function useStudent(id: string | undefined) {
  return useQuery({
    queryKey: queryKeys.students.detail(id ?? ""),
    queryFn: () => studentsService.getById(id as string),
    enabled: Boolean(id),
  });
}

function useInvalidateStudentCaches() {
  const queryClient = useQueryClient();
  return () => {
    void queryClient.invalidateQueries({ queryKey: queryKeys.students.all });
    void queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.stats });
    void queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.recent });
    void queryClient.invalidateQueries({ queryKey: ["analytics"] });
  };
}

export function useCreateStudent() {
  const invalidate = useInvalidateStudentCaches();
  return useMutation({
    mutationFn: (input: StudentInput) => studentsService.create(input),
    onSuccess: invalidate,
  });
}

export function useUpdateStudent() {
  const queryClient = useQueryClient();
  const invalidate = useInvalidateStudentCaches();
  return useMutation({
    mutationFn: ({ id, input }: { id: string; input: StudentInput }) =>
      studentsService.update(id, input),
    onSuccess: (student) => {
      invalidate();
      queryClient.setQueryData(queryKeys.students.detail(student.id), student);
    },
  });
}

export function useDeleteStudent() {
  const invalidate = useInvalidateStudentCaches();
  return useMutation({
    mutationFn: (id: string) => studentsService.remove(id),
    onSuccess: invalidate,
  });
}
