import { z } from "zod";

export const studentSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Name must be at least 2 characters")
    .max(60, "Name is too long"),
  admissionNumber: z
    .string()
    .trim()
    .min(3, "Admission number must be at least 3 characters")
    .max(20, "Admission number is too long")
    .regex(/^[A-Za-z0-9-]+$/, "Use letters, numbers and dashes only"),
  class: z.string().min(1, "Please select a class"),
});

export type StudentFormValues = z.infer<typeof studentSchema>;
