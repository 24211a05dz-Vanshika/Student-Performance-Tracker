import { z } from "zod";
import { EXAM_TYPES, MAX_MARK, MIN_MARK } from "@/constants";

export const markSchema = z.object({
  studentId: z.string().min(1, "Please select a student"),
  examType: z.enum(EXAM_TYPES as unknown as [string, ...string[]], {
    errorMap: () => ({ message: "Please select an exam type" }),
  }),
  marks: z
    .coerce.number({ invalid_type_error: "Marks must be a number" })
    .int("Marks must be a whole number")
    .min(MIN_MARK, `Marks cannot be below ${MIN_MARK}`)
    .max(MAX_MARK, `Marks cannot exceed ${MAX_MARK}`),
});

export type MarkFormValues = z.infer<typeof markSchema>;
